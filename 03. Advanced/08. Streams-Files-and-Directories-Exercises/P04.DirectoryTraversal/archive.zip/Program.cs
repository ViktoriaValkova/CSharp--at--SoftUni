﻿namespace DirectoryTraversal
{
	using System;

	public class DirectoryTraversal
	{
		static void Main()
		{
			string path = Console.ReadLine();
			string reportFileName = @"\report.txt";

			string reportContent = TraverseDirectory(path);
			Console.WriteLine(reportContent);

			WriteReportToDesktop(reportContent, reportFileName);
		}

		public static string TraverseDirectory(string inputFolderPath)
		{
			Dictionary<string, List<FileInDir>> allFilesByDir= new Dictionary<string, List<FileInDir>>();
			string[] files = Directory.GetFiles(inputFolderPath);

			foreach (string currentFile in files)
			{
				FileInfo fileInfo = new FileInfo(currentFile);
				double length = fileInfo.Length;
				double sizeInKb = length / 1024.0;

				int indexOfPunkt = currentFile.LastIndexOf('.');
				string name = currentFile.Substring(0, indexOfPunkt);
				string extension = currentFile.Substring(indexOfPunkt, currentFile.Length - indexOfPunkt);

				FileInDir newFile = new FileInDir(name, extension, sizeInKb);

				if (!allFilesByDir.ContainsKey(extension))
				{
					allFilesByDir[extension] = new List<FileInDir>();
				}
				allFilesByDir[extension].Add(newFile);
			}
			string result = string.Empty;

			foreach (var kvp in allFilesByDir.OrderByDescending(x=>x.Value.Count).ThenBy(x=>x.Key))
			{
				result += kvp.Key+"\n";
				List<FileInDir> currentFiles = kvp.Value;

				foreach (var file in currentFiles.OrderBy(x=>x.Size))
				{
					result += $"--{file.Name}{file.Extension} - {file.Size}kb\n";
				}
			}
			return result;
;		}

		public static void WriteReportToDesktop(string textContent, string reportFileName)
		{
			string path = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

			path += reportFileName;

			File.WriteAllText(path, textContent);
		}      
	}

	public class FileInDir
	{
		public FileInDir (string name, string extension, double size)
		{
			Name  = name;
			Extension = extension;
			Size = size;
		}

		public string Name { get; set; }
		public string Extension { get; set; }
		public double Size { get; set; }
	}
}