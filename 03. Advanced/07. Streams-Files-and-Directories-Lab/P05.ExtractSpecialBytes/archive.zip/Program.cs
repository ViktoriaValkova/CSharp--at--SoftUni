﻿namespace ExtractSpecialBytes
{
	using System;
	using System.IO;
	public class ExtractSpecialBytes
	{
		static void Main()
		{
			string binaryFilePath = @"..\..\..\Files\example.png";
			string bytesFilePath = @"..\..\..\Files\bytes.txt";
			string outputPath = @"..\..\..\Files\output.bin";

			ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
		}

		public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
		{
				List<byte> byteList = new List<byte>();
			using (StreamReader bytes = new StreamReader(bytesFilePath))
			{
				string bytesLine = string.Empty;

				while ((bytesLine = bytes.ReadLine()) != null)
				{
					byteList.Add(byte.Parse(bytesLine));
				}
			}

			using (FileStream input = new FileStream(binaryFilePath, FileMode.Open))
			{
				using (FileStream output = new FileStream(outputPath, FileMode.Create))
				{
					byte[] buf = new byte[1024];
					while (true)
					{
						int bytesRead = input.Read(buf);
						if (bytesRead == 0)
						{
							break;
						}

						foreach (var b in buf)
						{
							if (byteList.Contains(b))
							{
								output.WriteByte(b);
							}
						}
					}
				}
			}
		}
	}
}